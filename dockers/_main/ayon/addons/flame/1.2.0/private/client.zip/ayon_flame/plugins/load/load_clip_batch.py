from copy import deepcopy
import os
import flame
from pprint import pformat
import ayon_flame.api as ayfapi
from ayon_core.lib import StringTemplate
from ayon_core.lib.transcoding import (
    VIDEO_EXTENSIONS,
    IMAGE_EXTENSIONS
)

class LoadClipBatch(ayfapi.ClipLoader):
    """Load a product to timeline as clip

    Place clip to timeline on its asset origin timings collected
    during conforming to project
    """

    product_types = {"render2d", "source", "plate", "render", "review"}
    representations = {"*"}
    extensions = set(
        ext.lstrip(".") for ext in IMAGE_EXTENSIONS.union(VIDEO_EXTENSIONS)
    )

    label = "Load as clip to current batch"
    order = -10
    icon = "code-fork"
    color = "orange"

    # settings
    reel_name = "AYON_LoadedReel"
    clip_name_template = "{batch}_{folder[name]}_{product[name]}<_{output}>"

    """ Anatomy keys from version context data and dynamically added:
        - {layerName} - original layer name token
        - {layerUID} - original layer UID token
        - {originalBasename} - original clip name taken from file
    """
    layer_rename_template = "{folder[name]}_{product[name]}<_{output}>"
    layer_rename_patterns = []

    def load(self, context, name, namespace, options):

        # get flame objects
        self.batch = options.get("batch") or flame.batch

        # load clip to timeline and get main variables
        version_entity = context["version"]
        version_attributes =version_entity["attrib"]
        version_name = version_entity["version"]
        colorspace = self.get_colorspace(context)

        clip_name_template = self.clip_name_template
        layer_rename_template = self.layer_rename_template
        # in case output is not in context replace key to representation
        if not context["representation"]["context"].get("output"):
            clip_name_template = clip_name_template.replace(
                "output", "representation")
            layer_rename_template = layer_rename_template.replace(
                "output", "representation")

        folder_entity = context["folder"]
        product_entity = context["product"]
        formatting_data = deepcopy(context["representation"]["context"])
        formatting_data["batch"] = self.batch.name.get_value()
        formatting_data.update({
            "asset": folder_entity["name"],
            "folder": {
                "name": folder_entity["name"],
            },
            "subset": product_entity["name"],
            "family": product_entity["productType"],
            "product": {
                "name": product_entity["name"],
                "type": product_entity["productType"],
            }
        })

        clip_name = StringTemplate(clip_name_template).format(
            formatting_data)

        # convert colorspace with ocio to flame mapping
        # in imageio flame section
        colorspace = self.get_native_colorspace(colorspace)
        self.log.info("Loading with colorspace: `{}`".format(colorspace))

        # create workfile path
        workfile_dir = options.get("workdir") or os.environ["AYON_WORKDIR"]
        openclip_dir = os.path.join(
            workfile_dir, clip_name
        )
        openclip_path = os.path.join(
            openclip_dir, clip_name + ".clip"
        )

        if not os.path.exists(openclip_dir):
            os.makedirs(openclip_dir)

        # prepare clip data from context and send it to openClipLoader
        path = self.filepath_from_context(context)
        loading_context = {
            "path": path.replace("\\", "/"),
            "colorspace": colorspace,
            "version": "v{:0>3}".format(version_name),
            "layer_rename_template": layer_rename_template,
            "layer_rename_patterns": self.layer_rename_patterns,
            "context_data": formatting_data
        }
        self.log.debug(pformat(
            loading_context
        ))
        self.log.debug(openclip_path)

        # make AYON clip file
        ayfapi.OpenClipSolver(
            openclip_path, loading_context, logger=self.log).make()

        # prepare Reel group in actual desktop
        opc = self._get_clip(
            clip_name,
            openclip_path
        )

        # add additional metadata from the version to imprint basic
        # folder attributes
        add_keys = [
            "frameStart", "frameEnd", "source", "author",
            "fps", "handleStart", "handleEnd"
        ]

        # move all version data keys to tag data
        data_imprint = {
            key: version_attributes.get(key, str(None))
            for key in add_keys
        }
        # add variables related to version context
        data_imprint.update({
            "version": version_name,
            "colorspace": colorspace,
            "objectName": clip_name
        })

        # TODO: finish the containerisation
        # opc_segment = ayfapi.get_clip_segment(opc)

        # return ayfapi.containerise(
        #     opc_segment,
        #     name, namespace, context,
        #     self.__class__.__name__,
        #     data_imprint)

        return opc

    def _get_clip(self, name, clip_path):
        reel = self._get_reel()

        # with maintained openclip as opc
        matching_clip = None
        for cl in reel.clips:
            if cl.name.get_value() != name:
                continue
            matching_clip = cl

        if not matching_clip:
            created_clips = flame.import_clips(str(clip_path), reel)
            return created_clips.pop()

        return matching_clip

    def _get_reel(self):

        matching_reel = [
            rg for rg in self.batch.reels
            if rg.name.get_value() == self.reel_name
        ]

        return (
            matching_reel.pop()
            if matching_reel
            else self.batch.create_reel(str(self.reel_name))
        )
