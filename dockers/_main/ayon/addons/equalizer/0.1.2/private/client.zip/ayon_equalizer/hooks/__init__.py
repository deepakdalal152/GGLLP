"""Hooks for AYON Equalizer."""
