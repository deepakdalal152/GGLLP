import pyblish.api

from ayon_core.pipeline.publish import (
    ValidateContentsOrder,
    PublishXmlValidationError,
    OptionalPyblishPluginMixin,
    RepairAction,
)


class ValidateExistingVersion(
    OptionalPyblishPluginMixin,
    pyblish.api.InstancePlugin
):
    label = "Validate Existing Version"
    order = ValidateContentsOrder

    hosts = ["traypublisher"]
    targets = ["local"]

    actions = [RepairAction]

    settings_category = "traypublisher"
    optional = True

    def process(self, instance):
        if not self.is_active(instance.data):
            return

        version = instance.data.get("version")
        if version is None:
            return

        last_version = instance.data.get("latestVersion")
        if last_version is None or last_version < version:
            return

        product_name = instance.data["productName"]
        msg = "Version {} already exists for product {}.".format(
            version, product_name)

        formatting_data = {
            "product_name": product_name,
            "folder_path": instance.data["folderPath"],
            "version": version
        }
        raise PublishXmlValidationError(
            self, msg, formatting_data=formatting_data)

    @classmethod
    def repair(cls, instance):
        create_context = instance.context.data["create_context"]
        created_instance = create_context.get_instance_by_id(
            instance.data["instance_id"])
        creator_attributes = created_instance["creator_attributes"]
        # Disable version override
        creator_attributes["use_next_version"] = True
        create_context.save_changes()
