import copy
import os
import subprocess
import tempfile
import re

import pyblish.api
from ayon_core.lib import (
    get_oiio_tool_args,
    get_ffmpeg_tool_args,
    get_ffprobe_data,

    is_oiio_supported,
    get_rescaled_command_arguments,

    path_to_subprocess_arg,
    run_subprocess,
)
from ayon_core.lib.transcoding import (
    oiio_color_convert,
    get_oiio_input_and_channel_args,
    get_oiio_info_for_input,
)

from ayon_core.lib.transcoding import VIDEO_EXTENSIONS, IMAGE_EXTENSIONS


class ExtractThumbnail(pyblish.api.InstancePlugin):
    """Create jpg thumbnail from sequence using ffmpeg"""

    label = "Extract Thumbnail"
    order = pyblish.api.ExtractorOrder + 0.49
    families = [
        "imagesequence", "render", "render2d", "prerender",
        "source", "clip", "take", "online", "image"
    ]
    hosts = [
        "shell",
        "fusion",
        "resolve",
        "traypublisher",
        "substancepainter",
        "substancedesigner",
        "nuke",
        "aftereffects",
        "photoshop",
        "unreal",
        "houdini",
        "batchdelivery",
    ]
    settings_category = "core"
    enabled = False

    integrate_thumbnail = False
    target_size = {
        "type": "source",
        "resize": {
            "width": 1920,
            "height": 1080
        }
    }
    background_color = (0, 0, 0, 0.0)
    duration_split = 0.5
    # attribute presets from settings
    oiiotool_defaults = {
        "type": "colorspace",
        "colorspace": "color_picking",
        "display_and_view": {
            "display": "default",
            "view": "sRGB"
        }
    }
    ffmpeg_args = {
        "input": [],
        "output": []
    }
    product_names = []

    def process(self, instance):
        # run main process
        self._main_process(instance)

        # Make sure cleanup happens to representations which are having both
        # tags `delete` and `need_thumbnail`
        for repre in tuple(instance.data.get("representations", [])):
            tags = repre.get("tags") or []
            # skip representations which are going to be published on farm
            if "publish_on_farm" in tags:
                continue
            if (
                "delete" in tags
                and "need_thumbnail" in tags
            ):
                self.log.debug(
                    "Removing representation: {}".format(repre)
                )
                instance.data["representations"].remove(repre)

    def _main_process(self, instance):
        product_name = instance.data["productName"]
        instance_repres = instance.data.get("representations")
        if not instance_repres:
            self.log.debug((
                "Instance {} does not have representations. Skipping"
            ).format(product_name))
            return

        self.log.debug(
            "Processing instance with product name {}".format(product_name)
        )

        # Skip if instance have 'review' key in data set to 'False'
        if not self._is_review_instance(instance):
            self.log.debug("Skipping - no review set on instance.")
            return

        # Check if already has thumbnail created
        if self._already_has_thumbnail(instance_repres):
            self.log.debug("Thumbnail representation already present.")
            return

        # skip crypto passes.
        # TODO: This is just a quick fix and has its own side-effects - it is
        #       affecting every prouct name with `crypto` in its name.
        #       This must be solved properly, maybe using tags on
        #       representation that can be determined much earlier and
        #       with better precision.
        if "crypto" in product_name.lower():
            self.log.debug("Skipping crypto passes.")
            return

        # We only want to process the produces needed from settings.
        def validate_string_against_patterns(input_str, patterns):
            for pattern in patterns:
                if re.match(pattern, input_str):
                    return True
            return False

        product_names = self.product_names
        if product_names:
            result = validate_string_against_patterns(
                product_name, product_names
            )
            if not result:
                self.log.debug((
                    "Product name \"{}\" did not match settings filters: {}"
                ).format(product_name, product_names))
                return

        # first check for any explicitly marked representations for thumbnail
        explicit_repres = self._get_explicit_repres_for_thumbnail(instance)
        if explicit_repres:
            filtered_repres = explicit_repres
        else:
            filtered_repres = self._get_filtered_repres(instance)

        if not filtered_repres:
            self.log.info(
                "Instance doesn't have representations that can be used "
                "as source for thumbnail. Skipping thumbnail extraction."
            )
            return

        # Create temp directory for thumbnail
        # - this is to avoid "override" of source file
        dst_staging = tempfile.mkdtemp(prefix="pyblish_tmp_")
        self.log.debug(
            "Create temp directory {} for thumbnail".format(dst_staging)
        )
        # Store new staging to cleanup paths
        instance.context.data["cleanupFullPaths"].append(dst_staging)

        oiio_supported = is_oiio_supported()
        thumbnail_created = False
        for repre in filtered_repres:
            # Reset for each iteration to handle cases where multiple
            # reviewable thumbnails are needed
            repre_thumb_created = False
            repre_files = repre["files"]
            src_staging = os.path.normpath(repre["stagingDir"])
            if not isinstance(repre_files, (list, tuple)):
                # convert any video file to frame so oiio doesn't need to
                # read video file (it is slow) and also we are having control
                # over which frame is used for thumbnail
                # this will also work with ffmpeg fallback conversion in case
                # oiio is not supported
                repre_extension = os.path.splitext(repre_files)[1]
                if repre_extension in VIDEO_EXTENSIONS:
                    video_file_path = os.path.join(
                        src_staging, repre_files
                    )
                    file_path = self._create_frame_from_video(
                        video_file_path,
                        dst_staging
                    )
                    if file_path:
                        src_staging, input_file = os.path.split(file_path)
                else:
                    # if it is not video file then just use first file
                    input_file = repre_files
            else:
                repre_files_thumb = copy.deepcopy(repre_files)
                # exclude first frame if slate in representation tags
                if "slate-frame" in repre.get("tags", []):
                    repre_files_thumb = repre_files_thumb[1:]
                file_index = int(
                    float(len(repre_files_thumb)) * self.duration_split)
                input_file = repre_files[file_index]

            full_input_path = os.path.join(src_staging, input_file)
            self.log.debug("input {}".format(full_input_path))

            filename = os.path.splitext(input_file)[0]
            jpeg_file = filename + "_thumb.jpg"
            full_output_path = os.path.join(dst_staging, jpeg_file)
            colorspace_data = repre.get("colorspaceData")

            # NOTE We should find out what is happening here. Why don't we
            #   use oiiotool all the time if it is available? Only possible
            #   reason might be that video files should be converted using
            #   ffmpeg, but other then that, we should use oiio all the time.
            #   - We should also probably get rid of the ffmpeg settings...

            # only use OIIO if it is supported and representation has
            # colorspace data
            if oiio_supported and colorspace_data:
                self.log.debug(
                    "Trying to convert with OIIO "
                    "with colorspace data: {}".format(colorspace_data)
                )
                # If the input can read by OIIO then use OIIO method for
                # conversion otherwise use ffmpeg
                repre_thumb_created = self._create_colorspace_thumbnail(
                    full_input_path,
                    full_output_path,
                    colorspace_data
                )

            # Try to use FFMPEG if OIIO is not supported or for cases when
            #   oiiotool isn't available or representation is not having
            #   colorspace data
            if not repre_thumb_created:
                repre_thumb_created = self._create_thumbnail_ffmpeg(
                    full_input_path, full_output_path
                )

            # Skip representation and try next one if wasn't created
            if not repre_thumb_created and oiio_supported:
                repre_thumb_created = self._create_thumbnail_oiio(
                    full_input_path, full_output_path
                )

            if not repre_thumb_created:
                continue

            thumbnail_created = True
            if len(explicit_repres) > 1:
                repre_name = "thumbnail_{}".format(repre["outputName"])
            else:
                repre_name = "thumbnail"

            # add thumbnail path to instance data for integrator
            instance_thumb_path = instance.data.get("thumbnailPath")
            if (
                not instance_thumb_path
                or not os.path.isfile(instance_thumb_path)
            ):
                self.log.debug(
                    "Adding thumbnail path to instance data: {}".format(
                        full_output_path
                    )
                )
                instance.data["thumbnailPath"] = full_output_path

            new_repre_tags = ["thumbnail"]
            # for workflows which needs to have thumbnails published as
            # separate representations `delete` tag should not be added
            if not self.integrate_thumbnail:
                new_repre_tags.append("delete")

            new_repre = {
                "name": repre_name,
                "ext": "jpg",
                "files": jpeg_file,
                "stagingDir": dst_staging,
                "thumbnail": True,
                "tags": new_repre_tags,
                # If source image is jpg then there can be clash when
                # integrating to making the output name explicit.
                "outputName": "thumbnail"
            }

            # adding representation
            instance.data["representations"].append(new_repre)

            if explicit_repres:
                # this key will then align assetVersion ftrack thumbnail sync
                new_repre["outputName"] = (
                    repre.get("outputName") or repre["name"])
                self.log.debug(
                    "Adding explicit thumbnail representation: {}".format(
                        new_repre))
            else:
                self.log.debug(
                    "Adding thumbnail representation: {}".format(new_repre)
                )
                # There is no need to create more then one thumbnail
                break

        if not thumbnail_created:
            self.log.warning("Thumbnail has not been created.")

    def _is_review_instance(self, instance):
        # TODO: We should probably handle "not creating" of thumbnail
        #   other way then checking for "review" key on instance data?
        if instance.data.get("review", True):
            return True
        return False

    def _already_has_thumbnail(self, repres):
        for repre in repres:
            self.log.debug("repre {}".format(repre))
            if repre["name"] == "thumbnail":
                return True
        return False

    def _get_explicit_repres_for_thumbnail(self, instance):
        src_repres = instance.data.get("representations") or []
        # This is mainly for Nuke where we have multiple representations for
        #   one instance and representations are tagged for thumbnail.
        # First check if any of the representations have
        # `need_thumbnail` in tags and add them to filtered_repres
        need_thumb_repres = [
            repre for repre in src_repres
            if "need_thumbnail" in repre.get("tags", [])
            if "publish_on_farm" not in repre.get("tags", [])
        ]
        if not need_thumb_repres:
            return []

        self.log.info(
            "Instance has representation with tag `need_thumbnail`. "
            "Using only this representations for thumbnail creation. "
        )
        self.log.debug(
            "Representations: {}".format(need_thumb_repres)
        )
        return need_thumb_repres

    def _get_filtered_repres(self, instance):
        review_repres = []
        other_repres = []
        src_repres = instance.data.get("representations") or []

        for repre in src_repres:
            self.log.debug(repre)
            tags = repre.get("tags") or []

            if "publish_on_farm" in tags:
                # only process representations with are going
                # to be published locally
                continue

            if not repre.get("files"):
                self.log.debug((
                    "Representation \"{}\" doesn't have files. Skipping"
                ).format(repre["name"]))
                continue

            if "review" in tags:
                review_repres.append(repre)
            elif self._is_valid_images_repre(repre):
                other_repres.append(repre)

        return review_repres + other_repres

    def _is_valid_images_repre(self, repre):
        """Check if representation contains valid image files

        Args:
            repre (dict): representation

        Returns:
            bool: whether the representation has the valid image content
        """
        # Get first file's extension
        first_file = repre["files"]
        if isinstance(first_file, (list, tuple)):
            first_file = first_file[0]

        ext = os.path.splitext(first_file)[1].lower()

        return ext in IMAGE_EXTENSIONS or ext in VIDEO_EXTENSIONS

    def _create_colorspace_thumbnail(
        self,
        src_path,
        dst_path,
        colorspace_data,
    ):
        """Create thumbnail using OIIO tool oiiotool

        Args:
            src_path (str): path to source file
            dst_path (str): path to destination file
            colorspace_data (dict): colorspace data from representation
                keys:
                    colorspace (str)
                    config (dict)
                    display (Optional[str])
                    view (Optional[str])

        Returns:
            str: path to created thumbnail
        """
        self.log.info("Extracting thumbnail {}".format(dst_path))
        resolution_arg = self._get_resolution_arg("oiiotool", src_path)

        repre_display = colorspace_data.get("display")
        repre_view = colorspace_data.get("view")
        oiio_default_display = None
        oiio_default_view = None
        oiio_default_colorspace = None
        # first look into representation colorspaceData, perhaps it has
        #   display and view
        if all([repre_display, repre_view]):
            self.log.info(
                "Using Display & View from "
                "representation: '{} ({})'".format(
                    repre_view,
                    repre_display
                )
            )
        # if representation doesn't have display and view then use
        #   oiiotool_defaults
        elif self.oiiotool_defaults:
            oiio_default_type = self.oiiotool_defaults["type"]
            if "colorspace" == oiio_default_type:
                oiio_default_colorspace = self.oiiotool_defaults["colorspace"]
            else:
                display_and_view = self.oiiotool_defaults["display_and_view"]
                oiio_default_display = display_and_view["display"]
                oiio_default_view = display_and_view["view"]

        try:
            oiio_color_convert(
                src_path,
                dst_path,
                colorspace_data["config"]["path"],
                colorspace_data["colorspace"],
                source_display=colorspace_data.get("display"),
                source_view=colorspace_data.get("view"),
                target_display=repre_display or oiio_default_display,
                target_view=repre_view or oiio_default_view,
                target_colorspace=oiio_default_colorspace,
                additional_command_args=resolution_arg,
                logger=self.log,
            )
        except Exception:
            self.log.warning(
                "Failed to create thumbnail using oiiotool",
                exc_info=True
            )
            return False

        return True

    def _create_thumbnail_oiio(self, src_path, dst_path):
        self.log.debug(f"Extracting thumbnail with OIIO: {dst_path}")

        try:
            resolution_arg = self._get_resolution_arg("oiiotool", src_path)
        except RuntimeError:
            self.log.warning(
                "Failed to create thumbnail using oiio", exc_info=True
            )
            return False

        input_info = get_oiio_info_for_input(src_path, logger=self.log)
        input_arg, channels_arg = get_oiio_input_and_channel_args(input_info)
        oiio_cmd = get_oiio_tool_args(
            "oiiotool",
            input_arg, src_path,
            # Tell oiiotool which channels should be put to top stack
            #   (and output)
            "--ch", channels_arg,
            # Use first subimage
            "--subimage", "0"
        )
        oiio_cmd.extend(resolution_arg)
        oiio_cmd.extend(("-o", dst_path))
        self.log.debug("Running: {}".format(" ".join(oiio_cmd)))
        try:
            run_subprocess(oiio_cmd, logger=self.log)
            return True
        except Exception:
            self.log.warning(
                "Failed to create thumbnail using oiiotool",
                exc_info=True
            )
            return False

    def _create_thumbnail_ffmpeg(self, src_path, dst_path):
        try:
            resolution_arg = self._get_resolution_arg("ffmpeg", src_path)
        except RuntimeError:
            self.log.warning(
                "Failed to create thumbnail using ffmpeg", exc_info=True
            )
            return False

        ffmpeg_path_args = get_ffmpeg_tool_args("ffmpeg")
        ffmpeg_args = self.ffmpeg_args or {}

        jpeg_items = [
            subprocess.list2cmdline(ffmpeg_path_args)
        ]
        # flag for large file sizes
        max_int = 2147483647
        jpeg_items.extend([
            "-y",
            "-analyzeduration", str(max_int),
            "-probesize", str(max_int),
        ])
        # use same input args like with mov
        jpeg_items.extend(ffmpeg_args.get("input") or [])
        # input file
        jpeg_items.extend(["-i", path_to_subprocess_arg(src_path)])
        # output arguments from presets
        jpeg_items.extend(ffmpeg_args.get("output") or [])
        # we just want one frame from movie files
        jpeg_items.extend(["-frames:v", "1"])

        if resolution_arg:
            jpeg_items.extend(resolution_arg)

        # output file
        jpeg_items.append(path_to_subprocess_arg(dst_path))
        subprocess_command = " ".join(jpeg_items)

        try:
            run_subprocess(
                subprocess_command, shell=True, logger=self.log
            )
            return True
        except Exception:
            self.log.warning(
                "Failed to create thumbnail using ffmpeg",
                exc_info=True
            )
            return False

    def _create_frame_from_video(self, video_file_path, output_dir):
        """Convert video file to one frame image via ffmpeg"""
        # create output file path
        base_name = os.path.basename(video_file_path)
        filename = os.path.splitext(base_name)[0]
        output_thumb_file_path = os.path.join(
            output_dir, "{}.png".format(filename))

        # Set video input attributes
        max_int = str(2147483647)
        video_data = get_ffprobe_data(video_file_path, logger=self.log)

        # Get duration or use a safe default (single frame)
        duration = 0
        for stream in video_data["streams"]:
            if stream.get("codec_type") == "video":
                stream_duration = float(stream.get("duration", 0))
                if stream_duration > duration:
                    duration = stream_duration

        # For very short videos, just use the first frame
        # Calculate seek position safely
        seek_position = 0.0
        # Only use timestamp calculation for videos longer than 0.1 seconds
        if duration > 0.1:
            seek_position = duration * self.duration_split

        # Build command args
        cmd_args = []
        if seek_position > 0.0:
            cmd_args.extend(["-ss", str(seek_position)])

        # Add generic ffmpeg commands
        cmd_args.extend([
            "-i", video_file_path,
            "-analyzeduration", max_int,
            "-probesize", max_int,
            "-y",
            "-frames:v", "1",
            output_thumb_file_path
        ])

        # create ffmpeg command
        cmd = get_ffmpeg_tool_args(
            "ffmpeg",
            *cmd_args
        )
        try:
            # run subprocess
            self.log.debug("Executing: {}".format(" ".join(cmd)))
            run_subprocess(cmd, logger=self.log)

            # Verify the output file was created
            if (
                os.path.exists(output_thumb_file_path)
                and os.path.getsize(output_thumb_file_path) > 0
            ):
                self.log.debug(
                    "Thumbnail created: {}".format(output_thumb_file_path))
                return output_thumb_file_path
            self.log.warning("Output file was not created or is empty")

            # Try to create thumbnail without offset
            # - skip if offset did not happen
            if "-ss" not in cmd_args:
                return None

            self.log.debug("Trying fallback without offset")
            # Remove -ss and its value
            ss_index = cmd_args.index("-ss")
            cmd_args.pop(ss_index)  # Remove -ss
            cmd_args.pop(ss_index)  # Remove the timestamp value

            # Create new command and try again
            cmd = get_ffmpeg_tool_args("ffmpeg", *cmd_args)
            self.log.debug("Fallback command: {}".format(" ".join(cmd)))
            run_subprocess(cmd, logger=self.log)

            if (
                os.path.exists(output_thumb_file_path)
                and os.path.getsize(output_thumb_file_path) > 0
            ):
                self.log.debug("Fallback thumbnail created")
                return output_thumb_file_path
            return None
        except RuntimeError as error:
            self.log.warning(
                "Failed intermediate thumb source using ffmpeg: {}".format(
                    error)
            )
            return None
        finally:
            # Remove output file if is empty
            if (
                os.path.exists(output_thumb_file_path)
                and os.path.getsize(output_thumb_file_path) == 0
            ):
                os.remove(output_thumb_file_path)

    def _get_resolution_arg(
        self,
        application,
        input_path,
    ):
        # get settings
        if self.target_size["type"] == "source":
            return []

        resize = self.target_size["resize"]
        target_width = resize["width"]
        target_height = resize["height"]

        # form arg string per application
        return get_rescaled_command_arguments(
            application,
            input_path,
            target_width,
            target_height,
            bg_color=self.background_color,
            log=self.log
        )
