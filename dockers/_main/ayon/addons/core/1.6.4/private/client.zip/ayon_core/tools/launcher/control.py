from typing import Optional

from ayon_core.lib import Logger, get_ayon_username
from ayon_core.lib.events import QueuedEventSystem
from ayon_core.addon import AddonsManager
from ayon_core.settings import get_project_settings, get_studio_settings
from ayon_core.tools.common_models import ProjectsModel, HierarchyModel

from .abstract import (
    AbstractLauncherFrontEnd,
    AbstractLauncherBackend,
    WorkfileItem,
)
from .models import (
    LauncherSelectionModel,
    ActionsModel,
    WorkfilesModel,
)

NOT_SET = object()


class BaseLauncherController(
    AbstractLauncherFrontEnd, AbstractLauncherBackend
):
    def __init__(self):
        self._project_settings = {}
        self._event_system = None
        self._log = None

        self._addons_manager = None

        self._username = NOT_SET

        self._selection_model = LauncherSelectionModel(self)
        self._projects_model = ProjectsModel(self)
        self._hierarchy_model = HierarchyModel(self)
        self._actions_model = ActionsModel(self)
        self._workfiles_model = WorkfilesModel(self)

    @property
    def log(self):
        if self._log is None:
            self._log = Logger.get_logger(self.__class__.__name__)
        return self._log

    @property
    def event_system(self):
        """Inner event system for launcher tool controller.

        Is used for communication with UI. Event system is created on demand.

        Returns:
            QueuedEventSystem: Event system which can trigger callbacks
                for topics.
        """

        if self._event_system is None:
            self._event_system = QueuedEventSystem()
        return self._event_system

    # ---------------------------------
    # Implementation of abstract methods
    # ---------------------------------
    # Events system
    def emit_event(self, topic, data=None, source=None):
        """Use implemented event system to trigger event."""

        if data is None:
            data = {}
        self.event_system.emit(topic, data, source)

    def register_event_callback(self, topic, callback):
        self.event_system.add_callback(topic, callback)

    def get_addons_manager(self) -> AddonsManager:
        if self._addons_manager is None:
            self._addons_manager = AddonsManager()
        return self._addons_manager

    # Entity items for UI
    def get_project_items(self, sender=None):
        return self._projects_model.get_project_items(sender)

    def get_folder_type_items(self, project_name, sender=None):
        return self._projects_model.get_folder_type_items(
            project_name, sender
        )

    def get_task_type_items(self, project_name, sender=None):
        return self._projects_model.get_task_type_items(
            project_name, sender
        )

    def get_folder_items(self, project_name, sender=None):
        return self._hierarchy_model.get_folder_items(project_name, sender)

    def get_task_items(self, project_name, folder_id, sender=None):
        return self._hierarchy_model.get_task_items(
            project_name, folder_id, sender
        )

    # Project settings for applications actions
    def get_project_settings(self, project_name):
        if project_name in self._project_settings:
            return self._project_settings[project_name]
        if project_name:
            settings = get_project_settings(project_name)
        else:
            settings = get_studio_settings()
        self._project_settings[project_name] = settings
        return settings

    # Entity for backend
    def get_project_entity(self, project_name):
        return self._projects_model.get_project_entity(project_name)

    def get_folder_entity(self, project_name, folder_id):
        return self._hierarchy_model.get_folder_entity(
            project_name, folder_id)

    def get_task_entity(self, project_name, task_id):
        return self._hierarchy_model.get_task_entity(project_name, task_id)

    # Selection methods
    def get_selected_project_name(self):
        return self._selection_model.get_selected_project_name()

    def set_selected_project(self, project_name):
        self._selection_model.set_selected_project(project_name)

    def get_selected_folder_id(self):
        return self._selection_model.get_selected_folder_id()

    def set_selected_folder(self, folder_id):
        self._selection_model.set_selected_folder(folder_id)

    def get_selected_task_id(self):
        return self._selection_model.get_selected_task_id()

    def get_selected_task_name(self):
        return self._selection_model.get_selected_task_name()

    def set_selected_task(self, task_id, task_name):
        self._selection_model.set_selected_task(task_id, task_name)

    def set_selected_workfile(self, workfile_id):
        self._selection_model.set_selected_workfile(workfile_id)

    def get_selected_context(self):
        return {
            "project_name": self.get_selected_project_name(),
            "folder_id": self.get_selected_folder_id(),
            "task_id": self.get_selected_task_id(),
            "task_name": self.get_selected_task_name(),
        }

    # Workfiles
    def get_workfile_items(
        self,
        project_name: Optional[str],
        task_id: Optional[str],
    ) -> list[WorkfileItem]:
        return self._workfiles_model.get_workfile_items(
            project_name,
            task_id,
        )

    # Actions
    def get_action_items(
        self, project_name, folder_id, task_id, workfile_id
    ):
        return self._actions_model.get_action_items(
            project_name, folder_id, task_id, workfile_id
        )

    def trigger_action(
        self,
        identifier,
        project_name,
        folder_id,
        task_id,
        workfile_id,
    ):
        self._actions_model.trigger_action(
            identifier,
            project_name,
            folder_id,
            task_id,
            workfile_id,
        )

    def trigger_webaction(self, context, action_label, form_data=None):
        self._actions_model.trigger_webaction(
            context, action_label, form_data
        )

    def get_action_config_values(self, context):
        return self._actions_model.get_action_config_values(context)

    def set_action_config_values(self, context, values):
        return self._actions_model.set_action_config_values(context, values)

    # General methods
    def refresh(self):
        self._emit_event("controller.refresh.started")

        self._project_settings = {}

        self._projects_model.reset()
        self._hierarchy_model.reset()

        self._actions_model.refresh()
        self._projects_model.refresh()

        self._emit_event("controller.refresh.finished")

    def refresh_actions(self):
        self._emit_event("controller.refresh.actions.started")

        # Refresh project settings (used for actions discovery)
        self._project_settings = {}
        # Refresh projects - they define applications
        self._projects_model.reset()
        # Refresh actions
        self._actions_model.refresh()
        # Reset workfiles model
        self._workfiles_model.reset()

        self._emit_event("controller.refresh.actions.finished")

    def get_my_tasks_entity_ids(self, project_name: str):
        username = self._get_my_username()
        assignees = []
        if username:
            assignees.append(username)
        return self._hierarchy_model.get_entity_ids_for_assignees(
            project_name, assignees
        )

    def _get_my_username(self):
        if self._username is NOT_SET:
            self._username = get_ayon_username()
        return self._username

    def _emit_event(self, topic, data=None):
        self.emit_event(topic, data, "controller")
