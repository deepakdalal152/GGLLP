# -*- coding: utf-8 -*-
"""Tools for loading looks to vray proxies."""
from collections import defaultdict
import logging

from maya import cmds
import ayon_api

from ayon_core.pipeline import get_current_project_name
import ayon_maya.api.lib as maya_lib
from . import lib
from .alembic import get_alembic_ids_cache


log = logging.getLogger(__name__)


def assign_vrayproxy_shaders(vrayproxy, assignments):
    # type: (str, dict) -> None
    """Assign shaders to content of Vray Proxy.

    This will create shader overrides on Vray Proxy to assign shaders to its
    content.

    Todo:
        Allow to optimize and assign a single shader to multiple shapes at
        once or maybe even set it to the highest available path?

    Args:
        vrayproxy (str): Name of Vray Proxy
        assignments (dict): Mapping of shader assignments.

    Returns:
        None

    """
    # Clear all current shader assignments
    plug = vrayproxy + ".shaders"
    num = cmds.getAttr(plug, size=True)
    for i in reversed(range(num)):
        cmds.removeMultiInstance("{}[{}]".format(plug, i), b=True)

    # Create new assignment overrides
    index = 0
    for material, paths in assignments.items():
        for path in paths:
            plug = "{}.shaders[{}]".format(vrayproxy, index)
            cmds.setAttr(plug + ".shadersNames", path, type="string")
            cmds.connectAttr(material + ".outColor",
                             plug + ".shadersConnections", force=True)
            index += 1


def vrayproxy_assign_look(vrayproxy, product_name="lookMain"):
    # type: (str, str) -> None
    """Assign look to vray proxy.

    Args:
        vrayproxy (str): Name of vrayproxy to apply look to.
        product_name (str): Name of look product.

    Returns:
        None

    """
    path = cmds.getAttr(vrayproxy + ".fileName")

    nodes_by_id = get_alembic_ids_cache(path)
    if not nodes_by_id:
        log.warning("Alembic file has no cbId attributes: %s" % path)
        return

    # Group by asset id so we run over the look per asset
    node_ids_by_asset_id = defaultdict(set)
    for node_id in nodes_by_id:
        folder_id = node_id.split(":", 1)[0]
        node_ids_by_asset_id[folder_id].add(node_id)

    project_name = get_current_project_name()
    for folder_id, node_ids in node_ids_by_asset_id.items():

        # Get latest look version
        version_entity = ayon_api.get_last_version_by_product_name(
            project_name,
            product_name,
            folder_id,
            fields={"id"}
        )
        if not version_entity:
            print("Didn't find last version for product name {}".format(
                product_name
            ))
            continue
        version_id = version_entity["id"]

        relationships = lib.get_look_relationships(version_id)
        shadernodes, _ = lib.load_look(version_id)

        # Get only the node ids and paths related to this asset
        # And get the shader edits the look supplies
        asset_nodes_by_id = {
            node_id: nodes_by_id[node_id] for node_id in node_ids
        }
        edits = list(
            maya_lib.iter_shader_edits(
                relationships, shadernodes, asset_nodes_by_id
            )
        )

        # Create assignments
        assignments = {}
        for edit in edits:
            if edit["action"] == "assign":
                nodes = edit["nodes"]
                shader = edit["shader"]
                if not cmds.ls(shader, type="shadingEngine"):
                    print("Skipping non-shader: %s" % shader)
                    continue

                inputs = cmds.listConnections(
                    shader + ".surfaceShader", source=True)
                if not inputs:
                    print("Shading engine missing material: %s" % shader)

                # Strip off component assignments
                for i, node in enumerate(nodes):
                    if "." in node:
                        log.warning(
                            ("Converting face assignment to full object "
                             "assignment. This conversion can be lossy: "
                             "{}").format(node))
                        nodes[i] = node.split(".")[0]

                material = inputs[0]
                assignments[material] = nodes

        assign_vrayproxy_shaders(vrayproxy, assignments)
