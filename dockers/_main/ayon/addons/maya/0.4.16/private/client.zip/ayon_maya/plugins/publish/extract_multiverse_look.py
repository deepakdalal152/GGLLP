import os

from maya import cmds

from ayon_maya.api.lib import maintained_selection
from ayon_maya.api import plugin


class ExtractMultiverseLook(plugin.MayaExtractorPlugin):
    """Extractor for Multiverse USD look data.

    This will extract:

    - the shading networks that are assigned in MEOW as Maya material overrides
      to a Multiverse Compound
    - settings for a Multiverse Write Override operation.

    Relevant settings are visible in the Maya set node created by a Multiverse
    USD Look instance creator.

    The input data contained in the set is:

    - a single Multiverse Compound node with any number of Maya material
      overrides (typically set in MEOW)

    Upon publish two files will be written:

    - a .usda override file containing material assignment information
    - a .ma file containing shading networks

    Note: when layering the material assignment override on a loaded Compound,
          remember to set a matching attribute override with the namespace of
          the loaded compound in order for the material assignment to resolve.
    """

    label = "Extract Multiverse USD Look"
    families = ["mvLook"]
    scene_type = "usda"
    file_formats = ["usda", "usd"]

    @property
    def options(self):
        """Overridable options for Multiverse USD Export

        Given in the following format
            - {NAME: EXPECTED TYPE}

        If the overridden option's type does not match,
        the option is not included and a warning is logged.

        """

        return {
            "writeAll": bool,
            "writeTransforms": bool,
            "writeVisibility": bool,
            "writeAttributes": bool,
            "writeMaterials": bool,
            "writeVariants": bool,
            "writeVariantsDefinition": bool,
            "writeActiveState": bool,
            "writeNamespaces": bool,
            "numTimeSamples": int,
            "timeSamplesSpan": float
        }

    @property
    def default_options(self):
        """The default options for Multiverse USD extraction."""

        return {
            "writeAll": False,
            "writeTransforms": False,
            "writeVisibility": False,
            "writeAttributes": True,
            "writeMaterials": True,
            "writeVariants": False,
            "writeVariantsDefinition": False,
            "writeActiveState": False,
            "writeNamespaces": True,
            "numTimeSamples": 1,
            "timeSamplesSpan": 0.0
        }

    def get_file_format(self, instance):
        fileFormat = instance.data["fileFormat"]
        if fileFormat in range(len(self.file_formats)):
            self.scene_type = self.file_formats[fileFormat]

    def process(self, instance):
        # Load plugin first
        cmds.loadPlugin("MultiverseForMaya", quiet=True)

        # Define output file path
        staging_dir = self.staging_dir(instance)
        self.get_file_format(instance)
        file_name = "{0}.{1}".format(instance.name, self.scene_type)
        file_path = os.path.join(staging_dir, file_name)
        file_path = file_path.replace('\\', '/')

        # Parse export options
        options = self.default_options
        self.log.debug("Export options: {0}".format(options))

        # Perform extraction
        self.log.debug("Performing extraction ...")

        with maintained_selection():
            members = instance.data("setMembers")
            members = cmds.ls(members,
                              dag=True,
                              shapes=False,
                              type="mvUsdCompoundShape",
                              noIntermediate=True,
                              long=True)
            self.log.debug('Collected object {}'.format(members))
            if len(members) > 1:
                self.log.error('More than one member: {}'.format(members))

            import multiverse

            over_write_opts = multiverse.OverridesWriteOptions()
            options_discard_keys = {
                "numTimeSamples",
                "timeSamplesSpan",
                "frameStart",
                "frameEnd",
                "handleStart",
                "handleEnd",
                "step",
                "fps"
            }
            for key, value in options.items():
                if key in options_discard_keys:
                    continue
                setattr(over_write_opts, key, value)

            for member in members:
                # @TODO: Make sure there is only one here.

                self.log.debug("Writing Override for '{}'".format(member))
                multiverse.WriteOverrides(file_path, member, over_write_opts)

        if "representations" not in instance.data:
            instance.data["representations"] = []

        representation = {
            'name': self.scene_type,
            'ext': self.scene_type,
            'files': file_name,
            'stagingDir': staging_dir
        }
        instance.data["representations"].append(representation)

        self.log.debug("Extracted instance {} to {}".format(
            instance.name, file_path))
