# -*- coding: utf-8 -*-
"""Package declaring AYON addon 'ayon_third_party' version."""
__version__ = "1.4.0"
