# -*- coding: utf-8 -*-
import hou

import pyblish.api
from ayon_core.pipeline import PublishValidationError

from ayon_houdini.api import plugin


class ValidateCopOutputNode(plugin.HoudiniInstancePlugin):
    """Validate the instance COP2 Output Node.

    This will ensure:
        - The COP2 Path is set.
        - The COP2 Path refers to an existing object.
        - The COP2 Path node is a COP node.
    """

    order = pyblish.api.ValidatorOrder
    families = ["imagesequence"]
    label = "Validate COP2 Output Node"

    def process(self, instance):

        invalid = self.get_invalid(instance)
        if invalid:
            raise PublishValidationError(
                "Output node '{}' is incorrect. "
                "See plug-in log for details.".format(invalid[0].path()),
                title=self.label,
                description=(
                    "### Invalid COP2 output node\n\n"
                    "The output node path for the instance must be set to a "
                    "valid COP2 node path.\n\nSee the log for more details."
                )
            )

    @classmethod
    def get_invalid(cls, instance):
        output_node = instance.data.get("output_node")

        if not output_node:
            node = hou.node(instance.data.get("instance_node"))
            cls.log.error(
                "COP2 Output node in '%s' does not exist. "
                "Ensure a valid COP2 output path is set." % node.path()
            )

            return [node]

        # Output node must be a COP2 node.
        version = hou.applicationVersion()
        if version >= (20, 5, 0):
            # In Houdini 20.5 and later, COP2 nodes are used and `hou.CopNode`
            # started referring to Copernicus nodes instead.
            class_type = hou.Cop2Node
        else:
            class_type = hou.CopNode

        node_category_name = output_node.type().category().name()
        if not isinstance(output_node, class_type):
            cls.log.error(
                "Output node %s is not a COP2 node. "
                "COP2 Path must point to a COP2 node, "
                "instead found category type: %s",
                output_node.path(), node_category_name
            )
            return [output_node]

        # For the sake of completeness also assert the category type
        # is Cop2 to avoid potential edge case scenarios even though
        # the isinstance check above should be stricter than this category
        if node_category_name != "Cop2":
            cls.log.error(
                "Output node %s is not of category Cop2.", output_node.path()
            )
            return [output_node]
